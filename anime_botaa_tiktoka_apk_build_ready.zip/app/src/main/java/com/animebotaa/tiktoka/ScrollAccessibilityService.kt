package com.animebotaa.tiktoka

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class ScrollAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var scheduled = false

    private val ticker = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("settings", MODE_PRIVATE)
            if (!prefs.getBoolean("scrolling", false)) {
                scheduled = false
                return
            }
            // Swipe is performed only while TikTok is the foreground app.
            val pkg = rootInActiveWindow?.packageName?.toString()
            if (pkg == "com.zhiliaoapp.musically" || pkg == "com.ss.android.ugc.trill") {
                val dm = resources.displayMetrics
                val x = dm.widthPixels * 0.5f
                val path = Path().apply {
                    moveTo(x, dm.heightPixels * 0.78f)
                    lineTo(x, dm.heightPixels * 0.28f)
                }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 350))
                    .build()
                dispatchGesture(gesture, null, null)
            }
            val seconds = listOf(5, 10, 15, 20, 30).getOrElse(prefs.getInt("interval", 2)) { 15 }
            handler.postDelayed(this, seconds * 1000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        scheduleIfNeeded()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        scheduleIfNeeded()
    }

    private fun scheduleIfNeeded() {
        val active = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("scrolling", false)
        if (active && !scheduled) {
            scheduled = true
            handler.post(ticker)
        } else if (!active && scheduled) {
            handler.removeCallbacks(ticker)
            scheduled = false
        }
    }

    override fun onInterrupt() {
        handler.removeCallbacks(ticker)
        scheduled = false
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }
}
