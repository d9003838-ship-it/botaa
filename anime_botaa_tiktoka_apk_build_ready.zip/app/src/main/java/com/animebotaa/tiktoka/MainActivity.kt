package com.animebotaa.tiktoka

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private lateinit var commentsBox: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFFF5F6FA.toInt())
        }
        val title = TextView(this).apply {
            text = "anime botaa tiktoka"
            textSize = 25f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF22243A.toInt())
        }
        root.addView(title)
        root.addView(label("Помощник для TikTok • Android 14"))

        status = label("Автопрокрутка: выключена")
        root.addView(status)

        root.addView(label("Интервал перелистывания"))
        val interval = Spinner(this)
        val choices = listOf("5 секунд", "10 секунд", "15 секунд", "20 секунд", "30 секунд")
        interval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices)
        val saved = prefs.getInt("interval", 2).coerceIn(0, choices.lastIndex)
        interval.setSelection(saved)
        interval.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                prefs.edit().putInt("interval", position).apply()
            }
        }
        root.addView(interval)

        root.addView(button("1. Разрешить автопрокрутку") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Найди Anime Botaa Tiktoka и включи службу", Toast.LENGTH_LONG).show()
        })
        root.addView(button("2. Открыть TikTok и начать прокрутку") {
            prefs.edit().putBoolean("scrolling", true).apply()
            val launch = packageManager.getLaunchIntentForPackage("com.zhiliaoapp.musically")
                ?: packageManager.getLaunchIntentForPackage("com.ss.android.ugc.trill")
            if (launch != null) startActivity(launch)
            else Toast.makeText(this, "TikTok не найден. Открой его вручную.", Toast.LENGTH_LONG).show()
            updateStatus()
        })
        root.addView(button("Пауза / остановить прокрутку") {
            prefs.edit().putBoolean("scrolling", false).apply()
            updateStatus()
        })

        root.addView(label("Мои комментарии (каждый с новой строки)"))
        commentsBox = EditText(this).apply {
            hint = "Например:\nКлассное видео!\nОчень интересно 🔥\nПродолжай в том же духе!"
            minLines = 4
            gravity = Gravity.TOP
            setText(prefs.getString("comments", "Классное видео!\\nОчень интересно 🔥\\nПродолжай в том же духе!"))
        }
        root.addView(commentsBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(button("Сохранить комментарии") {
            prefs.edit().putString("comments", commentsBox.text.toString()).apply()
            Toast.makeText(this, "Список сохранён", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("Выбрать случайный комментарий и скопировать") {
            val list = commentsBox.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (list.isEmpty()) {
                Toast.makeText(this, "Сначала добавь комментарии", Toast.LENGTH_SHORT).show()
            } else {
                val chosen = list.random()
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("TikTok comment", chosen))
                Toast.makeText(this, "Скопировано: $chosen\nВставь и отправь вручную в TikTok", Toast.LENGTH_LONG).show()
            }
        })
        root.addView(label("Комментарии не публикуются автоматически: проверь текст и нажми «Отправить» сам."))
        setContentView(root)
        updateStatus()
    }

    private fun label(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(0xFF555B70.toInt())
        setPadding(0, 12, 0, 8)
    }

    private fun button(caption: String, action: () -> Unit) = Button(this).apply {
        text = caption
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun updateStatus() {
        val active = prefs.getBoolean("scrolling", false)
        status.text = if (active) "Автопрокрутка: включена (нажми «Пауза», чтобы остановить)" else "Автопрокрутка: выключена"
    }
}
